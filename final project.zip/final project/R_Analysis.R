#Most freq stops
data <- read.csv('../Final Files/Traffic_Violations.csv', stringsAsFactors=FALSE)
stops_MD <- data[data$State == 'MD' ,]
freq_stop_causes <- table(stops_MD$Description)
freq_stops <- as.data.frame(freq_stop_causes)
df_plot <- freq_stops[freq_stops$Freq >= 15000 , ]
df_plot <- df_plot[order(df_plot$Freq, decreasing=TRUE), ]
df_plot$cumulative <- cumsum(df_plot$Freq)
df_plot$Var1 <- factor(df_plot$Var1, levels = df_plot$Var1)
df_plot$order <- 1:nrow(df_plot)
#plot bar chart for freq stops
library(ggplot2)
ggplot(df_plot, aes(x = df_plot$Var1, y = df_plot$Freq)) +
  geom_bar(stat = "identity") +
  coord_flip()

################################################################################
#Most frequent stops locations
locations_MD <- table(stops_MD$Location)
locations_MD <- as.data.frame(locations_MD)
most_freq_loc <- locations_MD[locations_MD$Freq > 750, ]
most_freq_loc <- most_freq_loc[order(most_freq_loc$Freq, decreasing=TRUE), ]
most_freq_loc$cumulative <- cumsum(most_freq_loc$Freq)
most_freq_loc$Var1 <- factor(most_freq_loc$Var1, levels = most_freq_loc$Var1)
most_freq_loc$order <- 1:nrow(most_freq_loc)
#plot bar chart for freq stops
library(ggplot2)
ggplot(most_freq_loc, aes(x = most_freq_loc$Var1, y = most_freq_loc$Freq)) +
  geom_bar(stat = "identity") +
  coord_flip()

################################################################################
#Plot all fatal location on the map
fatal <- stops_MD[stops_MD$Fatal == 'Yes', ]
#create trip route
require(RMySQL)
require(ggmap)
library(leaflet)
fatalLoc <- leaflet() %>%
  addTiles() %>%  # Add map tiles
  addMarkers(lng=fatal$Longitude, lat=fatal$Latitude, popup=fatal$Location)  

# Print the map
fatalLoc

###############################################################################
#Effect of alcohol on fatal, personal injuries, and property damage
library(ggplot2)
ggplot(stops_MD, aes(x=stops_MD$Alcohol, y=stops_MD$Fatal)) + geom_point()

df1 <- stops_MD[stops_MD$Alcohol =='No' & stops_MD$Fatal == 'No' ,]
df2 <- stops_MD[stops_MD$Alcohol =='No' & stops_MD$Fatal == 'Yes' ,]
df3 <- stops_MD[stops_MD$Alcohol =='Yes' & stops_MD$Fatal == 'No' ,]
df4 <- stops_MD[stops_MD$Alcohol =='Yes' & stops_MD$Fatal == 'Yes' ,]
df6 <- stops_MD[stops_MD$Alcohol =='Yes' & stops_MD$Personal.Injury == 'Yes' ,]
df7 <- stops_MD[stops_MD$Alcohol =='Yes' & stops_MD$Personal.Injury == 'No' ,]
df8 <- stops_MD[stops_MD$Alcohol =='No' & stops_MD$Personal.Injury == 'No' ,]
df9 <- stops_MD[stops_MD$Alcohol =='No' & stops_MD$Personal.Injury == 'Yes' ,]
df10 <- stops_MD[stops_MD$Alcohol =='No' & stops_MD$Property.Damage == 'Yes' ,]
df11 <- stops_MD[stops_MD$Alcohol =='No' & stops_MD$Property.Damage == 'No' ,]
df12 <- stops_MD[stops_MD$Alcohol =='Yes' & stops_MD$Property.Damage == 'No' ,]
df13 <- stops_MD[stops_MD$Alcohol =='Yes' & stops_MD$Property.Damage == 'Yes' ,]




